package com.example.cse3310.personaltutoringservice;

/**
 * Created by danie on 11/20/2017.
 */

public class AccountInfo {
    public String firstname = null;
    public String lastname = null;
    public String id = null;
    public String password = null;
    public String address = null;
    public String phonenumber = null;
    public String email = null;


    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String Firstname) {
        firstname = Firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String Lastname) {
        lastname = Lastname;
    }

    public String getId() {
        return id;
    }

    public void setId(String Id) {
        id = Id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String Password) {
        password = Password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String Address) {
        address = Address;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String Phonenumber) {
        phonenumber = Phonenumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String Email) {
        email = Email;
    }
}
