package com.example.cse3310.personaltutoringservice;

import android.accounts.Account;
import android.app.Application;

import java.util.ArrayList;

/**
 * Created by danie on 11/20/2017.
 */

public class FullData extends Application {
    public Student[] studentlist = new Student[10];
    public Category[] categorylist = new Category[5];
    public Student tempstudent = new Student();
    public Tutor temptutor = new Tutor();
    public Student mainuserstudent = new Student();
    public Tutor mainusertutor = new Tutor();
    public Schedule tempSchedule = new Schedule();
    public Tutor prehiretutor = new Tutor();
    public TimeBlock editblock = new TimeBlock();
    public boolean tutorfound = false;
    public boolean tutorlogin = false;
    public boolean studentlogin = false;
    public int courschoosen = 0;
    public int studentcounter = 0;
    public int coursecounter = 0;
    public int blockdaychoice = 0;
    public int preCourse = 0;
    public int preTut = 0;
    public int mainSnumber = 0;
    public int mainCnumber = 0;
    public int mainTnumber = 0;


    public void addcategory (Category c){
        categorylist[coursecounter] = c;
        coursecounter++;
    }
    public void setEditblock(TimeBlock t){
        editblock = t;
    }
    public TimeBlock getEditblock(){
        return editblock;
    }
    public void setBlockdaychoice(int x){
        blockdaychoice = x;
    }
    public int getBlockdaychoice(){
        return blockdaychoice;
    }
    public int getCoursecounter(){
        return coursecounter;
    }


    public Category getcategory(int x){
        return categorylist[x];
    }

    public boolean gettutorlogin(){ return tutorlogin;}

    public boolean getstudentlogin(){return studentlogin;}

    public boolean gettutorfound(){
        return tutorfound;
    }

    public void addstudent(){
        Student temp = new Student();
       studentlist[studentcounter] = tempstudent;
       studentcounter++;
       tempstudent = temp;
    }
    public void addtutor(){
        Tutor temp = new Tutor();
        categorylist[courschoosen].addTutor(temptutor);
        temptutor = temp;
    }
    public void setschedule(){
        temptutor.setMySchedule(tempSchedule);
    }

    public Schedule getTempSchedule(){
        return tempSchedule;
    }

    public void setTempSchedule(Schedule t){
        tempSchedule = t;
    }
    public Tutor gettemptutor(){
        return temptutor;
    }
    public void setTemptutor(Tutor t){
        temptutor = t;
    }
    public Student getTempstudent(){
        return tempstudent;
    }
    public void setTempstudent( Student s){
        tempstudent = s;

    }
    public Tutor getMainusertutor(){
        return mainusertutor;
    }
    public void setMainusertutor(Tutor t){
        mainusertutor = t;
    }
    public Student getMainuserstudent(){
        return mainuserstudent;
    }
    public void setMainuserstudent(Student s){
        mainuserstudent = s;
    }
    public Tutor getPrehiretutor(){
        return prehiretutor;
    }
    public void setPrehiretutor(Tutor t){
        prehiretutor = t;
    }
    public void addcourse(Category c){
        categorylist[coursecounter] = c;
        coursecounter++;
    }

    public ArrayList<String>getnameslist(){
        String temp1 = null;
        Tutor temp = new Tutor();
        ArrayList<String> list = new ArrayList<String>();
        for(int i = 0; i < 5; i++){
            if(categorylist[i].getTutorcounter() > 0) {
                for (int j = 0; j < categorylist[i].getTutorcounter(); j++) {
                    temp = categorylist[i].getTutor(j);
                    temp1 = temp.gettutorname();
                    list.add(temp1);
                }
            }
        }
        return list;
    }
    public void findtutor(String t){
        String temp = null;
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < categorylist[i].getTutorcounter();j++){
                temp = categorylist[i].tutorlist[j].gettutorname();
                if(t.equals(temp)){
                  prehiretutor = categorylist[i].tutorlist[j];
                  preCourse = i;
                  preTut = j;
                  tutorfound = true;
                }
            }
        }
    }
    public void setCourschoosen(int t){
        courschoosen = t;
    }
    public void setpretutor(int t){
        prehiretutor = categorylist[courschoosen].tutorlist[t];
        preCourse =courschoosen;
        preTut = t;
        tutorfound = true;
    }
    public void tutorlogin( String one,String two){
        String temp = null;
        String test1 = null;
        Tutor giveme = new Tutor();
        String test2 = null;
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < categorylist[i].getTutorcounter();j++){

                     test1 = categorylist[i].tutorlist[j].gettutorid();
                     test2 = categorylist[i].tutorlist[j].gettutorpassword();
                     if(one.equals(test1) && two.equals(test2)) {
                         giveme = categorylist[i].getthetutor(j);
                         mainusertutor = giveme;
                         mainCnumber = i;
                         mainTnumber = j;
                         tutorlogin = true;
                     }

            }
        }

    }
    public void studentlogin(String one,String two){
        String temp = null;
        String test1 = null;
        for(int i = 0; i < studentcounter; i++){
            test1 = studentlist[i].getstudentid();
            temp = studentlist[i].getstudentpassword();
            if(one.equals(test1) && two.equals(temp) ){
                mainuserstudent = studentlist[i];
                mainSnumber = i;
                studentlogin = true;
            }
        }
    }

    public void startdata(){
        if(coursecounter == 0) {
            Category newC = new Category();
            AccountInfo a = new AccountInfo();
            AccountInfo aempty = new AccountInfo();
            Bankinfo bempty = new Bankinfo();
            Bankinfo b = new Bankinfo();
            Schedule tempsced =new Schedule();
            TimeBlock oneblock = new TimeBlock();
            TimeBlock twoblock = new TimeBlock();
            TimeBlock emptyblock = new TimeBlock();
            Schedule emptyscedule = new Schedule();

            String temp = "Math";
            newC.setCategory(temp);
            addcategory(newC);
            newC = new Category();
            temp = "Science";
            newC.setCategory(temp);
            addcategory(newC);
            newC = new Category();
            temp = "English";
            newC.setCategory(temp);
            addcategory(newC);
            newC = new Category();
            temp = "Music";
            newC.setCategory(temp);
            addcategory(newC);
            newC = new Category();
            temp = "Arts";
            newC.setCategory(temp);
            addcategory(newC);

            a.setFirstname("Daniel");
            a.setLastname("Benninghoff");
            a.setId("Hoff1234");
            a.setPassword("Zoro2009dmb");
            a.setPhonenumber("817-235-1285");
            a.setEmail("daniel.benninghoff@yahoo.com");
            b.setCardnumber("1265579927919911");
            b.setCSVsunumber("379");
            b.setCardtype("Visa");
            temptutor.setMyaccoutinfo(a);
            temptutor.setMybankinfo(b);
            oneblock.setStarttime("2:00pm");
            oneblock.setIstarttime(14);
            oneblock.setIfinishtime(16);
            oneblock.setFinishtime("4:00pm");
            oneblock.setStudent("Jina");
            oneblock.setTutor("Daniel");
            tempsced.addTomonday(oneblock);
            twoblock.setStarttime("4:00pm");
            twoblock.setIstarttime(16);
            twoblock.setIfinishtime(20);
            twoblock.setFinishtime("8:00pm");
            tempsced.addTomonday(twoblock);
            oneblock = emptyblock;
            twoblock = emptyblock;
            oneblock.setStarttime("2:00pm");
            oneblock.setIstarttime(14);
            oneblock.setIfinishtime(20);
            oneblock.setFinishtime("8:00pm");
            tempsced.addTofriday(oneblock);
            tempsced.addTosaturday(oneblock);
            temptutor.setMySchedule(tempsced);
            tempsced = emptyscedule;
            courschoosen = 0;
            addtutor();
            oneblock = emptyblock;
            tempsced = emptyscedule;
            a = aempty;
            b = bempty;

            a.setFirstname("Jina");
            a.setLastname("sparks");
            a.setId("sparks29");
            a.setPassword("Spark@1990");
            a.setPhonenumber("817-679-1499");
            a.setEmail("Jina@yahoo.com");
            b.setCardnumber("1267574433218811");
            b.setCSVsunumber("479");
            b.setCardtype("MasterCard");
            oneblock.setStarttime("2:00pm");
            oneblock.setIstarttime(14);
            oneblock.setIfinishtime(16);
            oneblock.setFinishtime("4:00pm");
            oneblock.setStudent("Jina");
            oneblock.setTutor("Daniel");
            tempsced.addTomonday(oneblock);
            tempstudent.setMyaccoutinfo(a);
            tempstudent.setMybankinfo(b);
            tempstudent.setMySchedule(tempsced);
            tempstudent.addtutorname("DanielBenninghoff");
            addstudent();


        }
        else if(coursecounter != 0){
            return;
        }
    }
    public void updatePreHire(){
        categorylist[mainCnumber].updatetutor(prehiretutor,mainTnumber);
    }
    public void updateMainTutor(){
        categorylist[mainCnumber].updatetutor( mainusertutor,mainTnumber);
    }
    public void updatemainStudent(){
        studentlist[mainSnumber] = mainuserstudent;
    }
}



