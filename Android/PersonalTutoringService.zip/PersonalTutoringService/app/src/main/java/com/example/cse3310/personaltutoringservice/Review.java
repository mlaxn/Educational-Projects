package com.example.cse3310.personaltutoringservice;

/**
 * Created by danie on 11/20/2017.
 */

public class Review {
    public float rating;
    public String review;

    public float getRating() {
        return rating;
    }

    public void setRating(float Rating) {
        rating = Rating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String Review) {
        review = Review;
    }
}


