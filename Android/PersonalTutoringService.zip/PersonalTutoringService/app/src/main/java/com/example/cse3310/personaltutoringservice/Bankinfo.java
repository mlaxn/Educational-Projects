package com.example.cse3310.personaltutoringservice;

/**
 * Created by danie on 11/20/2017.
 */

public class Bankinfo {

    public String cardnumber;
    public String CSVsunumber;
    public String cardtype;

    public String getCardnumber() {
        return cardnumber;
    }

    public void setCardnumber(String Cardnumber) {
        cardnumber = Cardnumber;
    }

    public String getCSVsunumber() {
        return CSVsunumber;
    }

    public void setCSVsunumber(String cSVsunumber) {
        CSVsunumber = cSVsunumber;
    }

    public String getCardtype() {
        return cardtype;
    }

    public void setCardtype(String Cardtype) {
        cardtype = Cardtype;
    }

}
