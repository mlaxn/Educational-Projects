package com.example.cse3310.personaltutoringservice;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Prehirepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prehirepage);
    }

    public void viewscedule(View view){
        Intent intend = new Intent(Prehirepage.this,ViewschedulePre.class);
        startActivity(intend);


    }
    public void viewrevs(View view){
        Intent intend = new Intent(Prehirepage.this,VeiwreviewsPre.class);
        startActivity(intend);
    }
    public void hiretutor(View view){
        Intent intend = new Intent(Prehirepage.this,Hire.class);
        startActivity(intend);


    }

}
